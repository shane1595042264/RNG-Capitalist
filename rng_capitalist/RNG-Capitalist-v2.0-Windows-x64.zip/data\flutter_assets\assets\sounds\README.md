This directory should contain:
- timer_complete.mp3: A sound file that plays when the timer completes

You can add your own custom sound files here. The app will gracefully handle missing files by showing a console message.
